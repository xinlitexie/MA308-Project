变量主要分为四个大类，如下所示

自身变量：
YEAR 进入NBA的年份

Age 年龄

Weight 体重

Height 身高

进攻变量 attack：
FT% Free Throw 罚球率

FGA Field Goal Attempted 投射数目

FG% Field Goal 场均得分数

ORB% offensive round bound 进攻篮板数

PTS Points 得分数

防守变量 defensive：
DRB% Defensive Rebound 防守篮板

STL% Steal 抢断

BLK% Block 场均抢断数

PF Personal Foul 个人犯规

其他变量other：
MP Minutes Per Game 每场上阵时间统计

TOV% Turnover 失误